class Food{
  String name, image;
  int totalCount, remainingCount, cost, id;

  Food({this.name, this.image, this.remainingCount, this.cost, this.totalCount, this.id});
}