class Model{
  String name, image;
  int price;
  int count;

  Model(this.name, this.image, this.count, this.price);

}