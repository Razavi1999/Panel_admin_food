class Product{
  String image;
  String name;
  String description;
  int price;
  String author, publisher;

  Product(this.image, this.name, this.description, this.price, this.publisher, this.author);
}