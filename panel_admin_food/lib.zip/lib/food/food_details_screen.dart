import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:http/http.dart' as http;
import 'package:persian_fonts/persian_fonts.dart';
import 'package:persian_fonts/persian_fonts.dart';
import 'package:pie_chart/pie_chart.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert' as convert;

import '../constants.dart';

class FoodDetailsScreen extends StatefulWidget {
  static String id = 'food_details_screen';

  @override
  _FoodDetailsScreenState createState() => _FoodDetailsScreenState();
}

class _FoodDetailsScreenState extends State<FoodDetailsScreen> {
  int count = 0;
  bool isVisible;
  TextEditingController controller = TextEditingController();
  Map args;
  String token,
      username,
      text,
      messageText = 'گفت و گو',
      seller_username,
      buyer_username,
      date,
      selectedTime;
  int userId, serveId, price, foodId, selectedTimeId;
  bool isBuyer = true;
  String url = '$baseUrl/api/food';
  String timeUrl = '$baseUrl/api/food/times/';

  //get my_map => null;

  Future<String> getToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    token = prefs.getString('token');
    // token = 'Token 965eee7f0022dc5726bc4d03fca6bd3ffe756a1f';
    userId = prefs.getInt('user_id');
    username = prefs.getString('username');
    return token;
  }

  @override
  Widget build(BuildContext context) {
    args = ModalRoute.of(context).settings.arguments;
    serveId = args['serve_id'];
    foodId = args['food_id'];
    date=args['date'];
    isVisible = args['isVisible'];

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        centerTitle: true,
        backgroundColor: kPrimaryColor,
        elevation: 0.0,
        iconTheme: IconThemeData(color: darkGrey),
        actions: [
          IconButton(
            icon: Icon(
              Icons.chevron_right,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ],
        title: Text(
          ' جزئیات غذا',
          style:  PersianFonts.Shabnam.copyWith(
              color: Colors.white, fontWeight: FontWeight.w500, fontSize: 30.0),
        ),
      ),

      body: FutureBuilder(
      future: getToken(),
      builder: (context, snapshot) {
        if (snapshot.hasData &&
            snapshot.connectionState == ConnectionState.done) {
          print('${url}/?food_id=$foodId');
          return SingleChildScrollView(
            child: Column(
              children: [
                FutureBuilder(
                  future: http.get('${url}/?food_id=$foodId&date=$date',
                      headers: {HttpHeaders.authorizationHeader: token}),

                  builder: (context, snapshot) {
                    if (snapshot.hasData &&
                        snapshot.connectionState == ConnectionState.done) {

                      http.Response response = snapshot.data;
                      print('***************************');
                      print(response.body);
                      print('***************************');

                      List result = convert.jsonDecode(
                          convert.utf8.decode(response.bodyBytes));
                      price = result[0]['cost'];
                      count = 0;

                      final Map<String , double> my_map = Map() ;

                      for(int i = 0 ; i < result.length ; i++)
                        my_map[replaceFarsiNumber( '${result[i]['start_serve_time'].toString().substring(0,5)} - ${result[i]['end_serve_time'].toString().substring(0,5)}' )]
                        = double.parse( result[i]['remaining_count'].toString());

                      print('my_map' + my_map.toString());

                      for (var each in result)
                        count++;

                      return SingleChildScrollView(
                        child: Column(
                          children: [
                            Container(
                              child: Center(
                                child: Banner(
                                  color: Colors.purple.shade300,
                                  message: result[0]['food']['cost'].toString(),
                                  location: BannerLocation.bottomEnd,
                                  child: FadeInImage(
                                    height: 150,
                                    width: 150,
                                    fit: BoxFit.cover,
                                    placeholder: AssetImage(
                                        'assets/images/book-1.png'),
                                    image: NetworkImage(
                                      '$baseUrl' + result[0]['food']['image'],
                                    ),
                                  ),
                                ),
                              ),
                              height: 200,
                              decoration: BoxDecoration(
                                color: kPrimaryColor,
                                borderRadius: BorderRadius.only(
                                  bottomLeft: Radius.circular(40),
                                  bottomRight: Radius.circular(40),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(
                                horizontal: 20,
                                vertical: 5,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Text(
                                    'نام غذا',
                                    style: PersianFonts.Shabnam.copyWith(
                                        color: kPrimaryColor,
                                        fontSize: 28),
                                    textDirection: TextDirection.rtl,
                                    textAlign: TextAlign.right,
                                  ),
                                ],
                              ),
                            ),



                            Padding(
                              padding: EdgeInsets.symmetric(
                                horizontal: 30,
                                vertical: 0,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Text(
                                    result[0]['food']['name'],
                                    textDirection: TextDirection.rtl,
                                    style: PersianFonts.Shabnam.copyWith(
                                        fontWeight: FontWeight.w800,
                                        color: kPrimaryColor,
                                        fontSize: 15
                                    ),
                                    textAlign: TextAlign.right,
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(
                                horizontal: 30,
                                vertical: 0,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Text(
                                    replaceFarsiNumber(result[0]['food']['cost'].toString()) + ' تومان',
                                    textDirection: TextDirection.rtl,
                                    textAlign: TextAlign.right,
                                    style: PersianFonts.Shabnam.copyWith(
                                        fontWeight: FontWeight.w800,
                                        color: kPrimaryColor,
                                        fontSize: 15
                                    ),
                                  ),
                                ],
                              ),
                            ),



                            Padding(
                              padding: EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 10,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 20,
                                      vertical: 5,
                                    ),
                                    child: Text(
                                      'محتویات',
                                      style: PersianFonts.Shabnam.copyWith(
                                          color: kPrimaryColor,
                                          fontSize: 28),
                                      textDirection: TextDirection.rtl,
                                      textAlign: TextAlign.right,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(
                                horizontal: 30,
                                vertical: 0,
                              ),
                              child: Text(
                                  result[0]['food']['description'],
                                  style: PersianFonts.Shabnam.copyWith(
                                      fontWeight: FontWeight.w800,
                                      color: kPrimaryColor
                                  ),
                                textDirection: TextDirection.rtl,
                              ),
                            ),
                            SizedBox(
                              height: 50,
                            ),

                            PieChart(
                              dataMap: my_map,
                              legendFontColor: Colors.blueGrey[900],
                              legendFontSize: 18.0,
                              legendFontWeight: FontWeight.w800,
                              animationDuration: Duration(milliseconds: 800),
                              chartLegendSpacing: 25.0,
                              chartRadius: MediaQuery.of(context).size.width / 2,
                              showChartValuesInPercentage: true,
                              //showChartValues: true,
                              //showChartValuesOutside: false,
                              chartValuesColor: Colors.blueGrey[900].withOpacity(0.9),
                              //colorList: colorList,
                              //showLegends: true,
                              //decimalPlaces: 1,
                              //showChartValueLabel: true,
                              //chartValueFontSize: 12,
                              //chartValueFontWeight: FontWeight.bold,
                              //chartValueLabelColor: Colors.grey[200],
                              //initialAngle: 0,
                            ),





                            ListView.builder(
                              shrinkWrap: true,
                              itemCount: count,
                              itemBuilder: (context, index) {



                                return Card(
                                  shape:  RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(15.0),
                                  ),
                                  color: Colors.white,
                                  margin: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                                  elevation: 6,


                                  child: ListTile(
                                    title: Text(
                                      replaceFarsiNumber(result[index]['start_serve_time']).substring(0,5)
                                          + ' تا ' +
                                          replaceFarsiNumber(result[index]['end_serve_time']).substring(0,5),

                                      style: PersianFonts.Shabnam.copyWith(
                                          fontWeight: FontWeight.w700
                                      ),
                                      textDirection: TextDirection.rtl,
                                    ),
                                    leading: Text(
                                      'تعداد باقیمانده: ${replaceFarsiNumber(result[index]['remaining_count'].toString())}',
                                      style: PersianFonts.Shabnam.copyWith(
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),

                                );
                                return SizedBox();
                              },
                            ),
                          ],
                        ),
                      );
                    } else {
                      return Container(
                        height: MediaQuery.of(context).size.height * 0.8,
                        child: Center(
                          child: SpinKitWave(
                            color: kPrimaryColor,
                          ),
                        ),
                      );
                    }
                  },
                ),
              ],
            ),
          );
        } else {
          return Center(
            child: CircularProgressIndicator(),
          );
        }
      },
    ),
    );
  }


  cancelDialog() async {
    var result = await showDialog(
      context: context,
      child: AlertDialog(
        title: Text(
          'آیا مطمین از لغو رزرو هستید ؟',
          textDirection: TextDirection.rtl,
        ),
        content: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FlatButton(
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: Text(
                'آره',
                style: PersianFonts.Shabnam.copyWith(color: Colors.green),
              ),
            ),
            SizedBox(
              width: 50,
            ),
            FlatButton(
              onPressed: () {
                Navigator.pop(context, false);
              },
              child: Text(
                'نه',
                style: PersianFonts.Shabnam.copyWith(color: Colors.green),
              ),
            ),
          ],
        ),
      ),
    );
    if (result == true) {}
  }
}
