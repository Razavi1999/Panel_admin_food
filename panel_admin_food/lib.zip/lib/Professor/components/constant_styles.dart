import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:persian_fonts/persian_fonts.dart';

const kTextFieldStyle = PersianFonts.Shabnam;